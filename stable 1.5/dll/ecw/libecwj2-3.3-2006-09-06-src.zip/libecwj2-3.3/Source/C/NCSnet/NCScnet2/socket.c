/********************************************************
** Copyright 1999 Earth Resource Mapping Pty Ltd.
** This document contains unpublished source code of
** Earth Resource Mapping Pty Ltd. This notice does
** not indicate any intention to publish the source
** code contained herein.
**
** FILE:   	NCScnet2\socket.c
** CREATED:	
** AUTHOR: 	Simon Cope
** PURPOSE:	sockets stuff
** EDITS:
 *******************************************************/

#include "cnet.h"


