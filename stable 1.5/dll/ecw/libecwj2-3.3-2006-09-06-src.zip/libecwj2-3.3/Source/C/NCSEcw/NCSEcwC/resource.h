// Empty header, just to keep resource compiler happy!
